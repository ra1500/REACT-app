import React from "react";

class Introduction extends React.Component {

  //constructor(props) {
  //  super(props);
  //}

  render() {
    return (
    <div id="introduction">
         <span> Life Scores. Who are you. How do you compare. </span><br></br>
         <span> Decisions to be made. Ask your network. </span><br></br>
         <span> Destiny. Find out what it may be. </span><br></br>
         <span> Sports games. Who will win. Ask your friends. </span><br></br>
         <span> Science problem. Your colleagues might know the right solution. </span><br></br>  <br></br>

         <span>&nbsp; &nbsp; Score &nbsp; > &nbsp; Choose your answers carefully</span><br></br>
         <span>&nbsp; &nbsp; &nbsp; Pose &nbsp; > &nbsp; Inquire to understand</span><br></br>
         <span>Connect &nbsp; > &nbsp; Network with your invited friends</span><br></br>
         <span>&nbsp; &nbsp; &nbsp; &nbsp; Ego &nbsp; > &nbsp; View your outcomes. Share with your network or the world</span><br></br>
         <br></br>



    </div>

    );
  }
}

export default Introduction;
