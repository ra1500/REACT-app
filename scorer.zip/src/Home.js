import Introduction from "./Introduction";
//import TitleBar from "./TitleBar";
import React from "react";

function Home(props) {
  return   <div>
            <Introduction />
           </div>;
}

export default Home;